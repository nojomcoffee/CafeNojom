body {
    font-family: sans-serif;
    background-color: white;
    color: black;
    margin: 0;
    padding: 0;
}
header, footer {
    background-color: #111;
    color: #0f0;
    padding: 10px;
    text-align: center;
}
h1 {
    font-size: 2rem;
}
main {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    padding: 1rem;
}
.menu-item {
    border: 1px solid #0f0;
    margin: 10px;
    padding: 10px;
    width: 200px;
    text-align: center;
    background: #fff;
    border-radius: 10px;
}
.menu-item img {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: 10px;
}
button {
    background-color: #0f0;
    color: black;
    border: none;
    padding: 5px 10px;
    margin-top: 5px;
    cursor: pointer;
}
#cart {
    background: #f0f0f0;
    padding: 1rem;
    border-top: 2px solid #0f0;
}
#cart input {
    display: block;
    margin: 5px 0;
    padding: 5px;
    width: 100%;
}